//
//  ViewController.swift
//  ThumbLockDemo
//
//  Created by Ankit Gabani on 03/08/18.
//  Copyright © 2018 Ankit Gabani. All rights reserved.
//

import UIKit
import LocalAuthentication

class ViewController: UIViewController
{
    //MARK:- IBOutlet
    @IBOutlet weak var btnLogout: UIButton!
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var lblMesaage: UILabel!
    
    let kMsgShowFinger = "Show me your finger 👍"
    let kMsgShowReason = "Only awesome people are allowed"
    let kMsgFingerOK = "Login successful! ✅"
    
    var context = LAContext()
    
    
    deinit {
        
        Utils.removeObserverForNotifications(observer: self)
    }
    
    //MARK:- View Cycle
    override func viewDidLoad()
    {
        context.localizedFallbackTitle = ""
        super.viewDidLoad()
        
        setupController()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        updateUI()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    private func setupController()
    {
        Utils.registerNotificationWillEnterForeground(observer: self, selector: #selector(ViewController.updateUI))
        
        btnLogout.alpha = 0
    }
    
    @objc func updateUI()
    {
        var policy: LAPolicy?
        
        if #available(iOS 9.0, *)
        {
            
            policy = .deviceOwnerAuthentication
        }
        else
        {
            
            context.localizedFallbackTitle = "Fuu!"
            policy = .deviceOwnerAuthenticationWithBiometrics
        }
        
        var err: NSError?
        
        
        guard context.canEvaluatePolicy(policy!, error: &err) else {
            images.image = UIImage(named: "TouchID_off")
            
            lblMesaage.text = err?.localizedDescription
            return
        }
        
        
        images.image = UIImage(named: "TouchID_on")
        lblMesaage.text = kMsgShowFinger
        
        loginProcess(policy: policy!)
    }
    
    private func loginProcess(policy: LAPolicy)
    {
        
        context.evaluatePolicy(policy, localizedReason: kMsgShowReason, reply: { (success, error) in
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.5, animations: {
                    self.btnLogout.alpha = 1
                })
                
                guard success else {
                    guard let error = error else {
                        self.showUnexpectedErrorMessage()
                        return
                    }
                    switch(error) {
                        
                        
                    case LAError.authenticationFailed:
                        self.lblMesaage.text = "There was a problem verifying your identity."
                        
                    case LAError.userCancel:
                        self.lblMesaage.text = "Authentication was canceled by user."
                    case LAError.userFallback:
                        self.lblMesaage.text = "The user tapped the fallback button (Fuu!)"
                    case LAError.systemCancel:
                        self.lblMesaage.text = "Authentication was canceled by system."
                        
                    case LAError.passcodeNotSet:
                        self.lblMesaage.text = "Passcode is not set on the device."
                    case LAError.touchIDNotAvailable:
                        self.lblMesaage.text = "Touch ID is not available on the device."
                    case LAError.touchIDNotEnrolled:
                        self.lblMesaage.text = "Touch ID has no enrolled fingers."
                        
                    case LAError.touchIDLockout:
                        self.lblMesaage.text = "There were too many failed Touch ID attempts and Touch ID is now locked."
                    case LAError.appCancel:
                        self.lblMesaage.text = "Authentication was canceled by application."
                    case LAError.invalidContext:
                        self.lblMesaage.text = "LAContext passed to this call has been previously invalidated."
                        
                    default:
                        self.lblMesaage.text = "Touch ID may not be configured"
                        break
                    }
                    return
                }
                
                self.lblMesaage.text = self.kMsgFingerOK
            }
        })
    }
    
    private func showUnexpectedErrorMessage()
    {
        images.image = UIImage(named: "TouchID_off")
        lblMesaage.text = "Unexpected error! 😱"
    }
    
    //MARK:- Action Method
    @IBAction func btnLogout(_ sender: AnyObject)
    {
        context = LAContext()
        context.localizedFallbackTitle = ""
        
        UIView.animate(withDuration: 0.5, animations: {
            self.btnLogout.alpha = 0
        })
        
        updateUI()
    }
    
    
    
}


