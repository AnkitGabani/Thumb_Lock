//
//  Utils.swift
//  ThumbLockDemo
//
//  Created by Ankit Gabani on 03/08/18.
//  Copyright © 2018 Ankit Gabani. All rights reserved.
//

import UIKit

class Utils {
    
    class func registerNotificationWillEnterForeground(observer: AnyObject, selector: Selector) {
        NotificationCenter.default.addObserver(observer, selector: selector, name: .UIApplicationWillEnterForeground, object: nil)
    }
    
    class func removeObserverForNotifications(observer: AnyObject) {
        NotificationCenter.default.removeObserver(observer)
    }
}
